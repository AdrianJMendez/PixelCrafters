{\rtf1\ansi\deff0{\fonttbl{\f0\fnil\fcharset0 Lucida Console;}}
\viewkind4\uc1\pard\lang1033\f0\fs17 ///////////////////////////////////////////////////////////////////////////
\par /This Font file was created by Digital Flame Studios. It may not be used /
\par /on any website except for Digital Flame, and Extreme-Tutorials.com     / 
\par /Font Copyright (C)2005+ Digital Flame Studios, All rights reserved .  /
\par ///////////////////////////////////////////////////////////////////////
\par 
\par Thank you for downloading this font made by Digital Flame Studios, please obey our copyright above, and do not distribute this font unless you have permission from us. This is for private use only. Thanks very much! 
\par 
\par ~Administrative Services 
\par }
 